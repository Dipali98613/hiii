package com.example.Dipali.Kale;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DipaliKaleApplication {

	public static void main(String[] args) {
		SpringApplication.run(DipaliKaleApplication.class, args);
	}

}
